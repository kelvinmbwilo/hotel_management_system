<?php
class Portifolio extends Eloquent {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'portifolio';

    protected  $guarded = array('id');


}