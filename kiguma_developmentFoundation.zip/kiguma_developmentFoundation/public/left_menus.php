  <div class="left_menu">
        <div class="caption">
        <img src="img/resource.jpg" alt="..." class="img-responsive img-circle">
        <h3>Project Resources</h3>
      </div>
      <ul class="nav nav-stacked">
          <li class="active"><a href="#">Documents <span class="glyphicon glyphicon-chevron-right pull-right"></span></a></li>
        <li class="active"><a href="#">Bronchours <span class="glyphicon glyphicon-chevron-right pull-right"></span></a></li>
        <li><a href="#">Web Materials <span class="glyphicon glyphicon-chevron-right pull-right"></span></a></li>
        <li><a href="#">Standards Definition <span class="glyphicon glyphicon-chevron-right pull-right"></span></a></li>
      </ul>
    </div>
    
<script type="text/javascript" src="js/menus.js"></script>
